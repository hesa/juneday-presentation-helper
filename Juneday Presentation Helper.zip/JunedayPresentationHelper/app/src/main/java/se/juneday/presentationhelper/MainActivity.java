package se.juneday.presentationhelper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import se.juneday.presentationhelper.network.SocketConnection;
import se.juneday.presentationhelper.ui.main.LoudMouthFragment;
import se.juneday.presentationhelper.ui.main.MainFragment;

public class MainActivity extends AppCompatActivity {

    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    FragmentPagerAdapter adapterViewPager;
    private SocketConnection connection;

    public static class MyPagerAdapter extends FragmentPagerAdapter {
        private static int NUM_ITEMS = 3;

        public MyPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        // Returns total number of pages
        @Override
        public int getCount() {
            return NUM_ITEMS;
        }

        // Returns the fragment to display for that page
        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0: // Fragment # 0 - This will show FirstFragment
                    return MainFragment.newInstance();
                case 1: // Fragment # 0 - This will show FirstFragment different title
                    return LoudMouthFragment.newInstance();
                case 2: // Fragment # 1 - This will show SecondFragment
                    return MainFragment.newInstance();
                default:
                    return null;
            }
        }

        // Returns the page title for the top indicator
        @Override
        public CharSequence getPageTitle(int position) {
            return "Page " + position;
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
/*        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, MainFragment.newInstance())
                    .commitNow();

        }
*/
        ViewPager vpPager = (ViewPager) findViewById(R.id.pager);
        adapterViewPager = new MyPagerAdapter(getSupportFragmentManager());
        vpPager.setAdapter(adapterViewPager);


        if (connection==null) {
            try {
                connection = new SocketConnection("einar", "hackner");
            } catch (SocketConnection.SocketException se) {
                Log.d(LOG_TAG, " failed creating socket");
            }
        }

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.about_item:
                return true;

            case R.id.settings_item:
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    public void sendCommand(String command) {
        Log.d(LOG_TAG, "sendCommand " + command);
        try {
            connection.sendCommand(command);
        } catch (SocketConnection.SocketException e) {
            e.printStackTrace();
        }
    }

    public void onForwardClick(View v) {
        sendCommand("right");
    }
    public void onBackClick(View v) {
        sendCommand("left");
    }
    public void onUpClick(View v) {
        sendCommand("up");
    }
    public void onDownClick(View v) {
        sendCommand("down");
    }

}