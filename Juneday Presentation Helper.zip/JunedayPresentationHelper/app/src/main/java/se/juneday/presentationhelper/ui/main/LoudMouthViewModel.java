package se.juneday.presentationhelper.ui.main;

import androidx.lifecycle.ViewModel;

public class LoudMouthViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
